function [bestX, bestJ, histBest] = gwo_inertia_trade(fitfun, D, lb, ub, opts)
% Grey Wolf Optimization (R2016a-safe)
if isscalar(lb), lb = lb*ones(1,D); end
if isscalar(ub), ub = ub*ones(1,D); end
N  = opts.pop;  MaxIt = opts.iters;

% Init
X = bsxfun(@plus, lb, bsxfun(@times, rand(N,D), (ub - lb)));
J = inf(N,1);
for i=1:N, J(i) = fitfun(X(i,:)); end

[bestJ, idx] = min(J); bestX = X(idx,:);
histBest = zeros(MaxIt,1);

for it = 1:MaxIt
    % Sort and pick alpha, beta, delta
    [J, ord] = sort(J);  X = X(ord,:);
    alpha = X(1,:);  beta = X(2,:);  delta = X(3,:);
    a = 2 - 2*(it-1)/(MaxIt-1); % linear decrease 2->0

    % Update positions
    for i = 1:N
        r1 = rand(1,D); r2 = rand(1,D);
        A1 = 2*a.*r1 - a;  C1 = 2.*r2;
        Dalpha = abs(C1.*alpha - X(i,:));
        X1 = alpha - A1.*Dalpha;

        r1 = rand(1,D); r2 = rand(1,D);
        A2 = 2*a.*r1 - a;  C2 = 2.*r2;
        Dbeta = abs(C2.*beta - X(i,:));
        X2 = beta - A2.*Dbeta;

        r1 = rand(1,D); r2 = rand(1,D);
        A3 = 2*a.*r1 - a;  C3 = 2.*r2;
        Ddelta = abs(C3.*delta - X(i,:));
        X3 = delta - A3.*Ddelta;

        X(i,:) = (X1 + X2 + X3)/3;
    end

    % Clamp & evaluate
    X = min(max(X, repmat(lb,N,1)), repmat(ub,N,1));
    for i=1:N, J(i) = fitfun(X(i,:)); end

    [curBest, idx] = min(J);
    if curBest < bestJ
        bestJ = curBest; bestX = X(idx,:);
    end
    histBest(it) = bestJ;
end
end

