function dump_kpi_table(KPI, outDir, cName)
hdr = {'Case','Method','ITAE','OS_f1','US_f1','ST_f1','OS_f2','US_f2','ST_f2','ST_Ptie'};
rows = {'Conventional','RES','GWO','PSO','DE'};
K = {KPI.Conventional, KPI.RES, KPI.GWO, KPI.PSO, KPI.DE};

fid = fopen(fullfile(outDir, [upper(cName) '_KPI.csv']),'w');
fprintf(fid,'%s,',hdr{1,1:end-1}); fprintf(fid,'%s\n',hdr{end});
for i=1:numel(K)
    ki = K{i};
    fprintf(fid,'%s,%s,%.6f,%.6f,%.6f,%.3f,%.6f,%.6f,%.3f,%.3f\n',...
        upper(cName), rows{i}, ki.ITAE, ki.OS_f1, ki.US_f1, ki.ST_f1, ki.OS_f2, ki.US_f2, ki.ST_f2, ki.ST_Ptie);
end
fclose(fid);
end
