
function main_compare()
% Driver: runs Cases I�IV, optimizes inertia (GWO/PSO/DE), plots & KPIs.
clc; close all; clear;

Ts   = 0.01;       % step size (s)
Tsim = 60;         % horizon (s)
t    = 0:Ts:Tsim;  % time vector
rng(42);

% Optimizer settings
opt.GWO.pop = 30; opt.GWO.iters = 100;
opt.PSO.pop = 30; opt.PSO.iters = 100; opt.PSO.w = 0.72; opt.PSO.c1 = 1.5; opt.PSO.c2 = 1.5;
opt.DE.pop  = 30; opt.DE.iters  = 100; opt.DE.F = 0.6;  opt.DE.CR  = 0.9;

lb = 0.40; ub = 1.20;  % bounds on inertia multipliers

% Load cases
cases = load_cases_user();
caseNames = fieldnames(cases);

for ci = 1:numel(caseNames)
    cName = caseNames{ci};
    sys   = cases.(cName);
    nA    = sys.nAreas;
    fprintf('\n=== Running %s (nAreas=%d) ===\n', upper(cName), nA);

    % Baselines
    Hconv = ones(1,nA);
    Hres  = 0.55*ones(1,nA);

    % Objective
    obj = @(Hmult) objective_itae(sys, Hmult(:)', t, Ts);

    % Optimize
    [Hgwo, Jgwo, curveGWO] = gwo_inertia_trade(obj, nA, lb, ub, opt.GWO);
    [Hpso, Jpso, curvePSO] = pso_inertia_trade(obj, nA, lb, ub, opt.PSO);
    [Hde , Jde , curveDE ] = de_inertia_trade (obj, nA, lb, ub, opt.DE );

    % Simulate all
    resConv = simulate_case(sys, Hconv, t, Ts);
    resRES  = simulate_case(sys, Hres , t, Ts);
    resGWO  = simulate_case(sys, Hgwo , t, Ts);
    resPSO  = simulate_case(sys, Hpso , t, Ts);
    resDE   = simulate_case(sys, Hde  , t, Ts);

    % KPIs
    KPI = struct();
    KPI.Conventional = compute_kpis(t, resConv);
    KPI.RES          = compute_kpis(t, resRES );
    KPI.GWO          = compute_kpis(t, resGWO );
    KPI.PSO          = compute_kpis(t, resPSO );
    KPI.DE           = compute_kpis(t, resDE  );

    % Output folder
    outDir = fullfile(pwd, ['OUT_' upper(cName)]);
    if ~exist(outDir,'dir'), mkdir(outDir); end

    % Plots & tables
    plot_freq_overlays(t, resConv, resRES, resGWO, resPSO, resDE, outDir, cName, nA);
    plot_tieline_overlay(t, resConv, resRES, resGWO, resPSO, resDE, outDir, cName);
    plot_convergence({curveGWO, curvePSO, curveDE}, {'GWO','PSO','DE'}, outDir, cName);
    plot_kpi_bars(KPI, outDir, cName);
    dump_kpi_table(KPI, outDir, cName);

    % Print best vectors
    fprintf('Best H (GWO): %s  J=%.6f\n', mat2str(Hgwo,3), Jgwo);
    fprintf('Best H (PSO): %s  J=%.6f\n', mat2str(Hpso,3), Jpso);
    fprintf('Best H (DE ): %s  J=%.6f\n', mat2str(Hde ,3), Jde );
end

fprintf('\nAll done. See OUT_* folders for figures and KPI CSVs.\n');
end
