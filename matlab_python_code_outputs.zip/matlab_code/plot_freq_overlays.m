function plot_freq_overlays(t, C, R, G, P, D, outDir, cName, nA)
fig = figure('Color','w','Position',[100 100 900 360]);
subplot(1, min(nA,3), 1);
plot(t,C.df1,'k--', t,R.df1,'r-', t,G.df1,'b', t,P.df1,'m', t,D.df1,'g','LineWidth',1.2);
grid on; xlabel('Time (s)'); ylabel('\Delta f_1 (Hz)');
legend('Conventional','RES (low H)','GWO','PSO','DE','Location','best'); title('\Delta f_1');

if nA>=2 && isfield(C,'df2')
subplot(1, min(nA,3), 2);
plot(t,C.df2,'k--', t,R.df2,'r-', t,G.df2,'b', t,P.df2,'m', t,D.df2,'g','LineWidth',1.2);
grid on; xlabel('Time (s)'); ylabel('\Delta f_2 (Hz)'); title('\Delta f_2');
end
if nA>=3 && isfield(C,'df3')
subplot(1,3,3);
plot(t,C.df3,'k--', t,R.df3,'r-', t,G.df3,'b', t,P.df3,'m', t,D.df3,'g','LineWidth',1.2);
grid on; xlabel('Time (s)'); ylabel('\Delta f_3 (Hz)'); title('\Delta f_3');
end
saveas(fig, fullfile(outDir, [upper(cName) '_freq_overlays.png']));
close(fig);
end


