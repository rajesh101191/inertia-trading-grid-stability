% ======================= simulate_case.m =========================
% Minimal two/three-area LFC model (governor + turbine + power block + tie-line)
% States per area: xg (governor), xt (turbine), xp (power/plant)
% ---------------------------------------------------------------
function res = simulate_case(p, Hmult, t, dt)

nA = p.nAreas;
N  = numel(t);

% scale inertias
H = p.Hbase(:)'.*Hmult(:)';      % inertia constants (area wise)

% preallocate
xg = zeros(nA,1);  % governor
xt = zeros(nA,1);  % turbine
xp = zeros(nA,1);  % plant output
df = zeros(N,nA);  % frequency deviations
dPtie = zeros(N,1);

% disturbance (step load in area-1 unless provided)
if isfield(p,'DPL1'), dPL = [p.DPL1, zeros(1,nA-1)]; else, dPL = [0.01, zeros(1,nA-1)]; end

for k = 1:N
    % frequency derivative from swing equation (linearized classic LFC):
    % 2H * d(df)/dt = -D*df - (1/R)*xw + xp - dPL - tie-coupling
    % Here xw is speed deviation ~ df (per LFC small-signal), so we use df.
    % We'll integrate with forward Euler.

    % tie-line power linearized (sum over i<->j): dPtie = sum(Tij*(df_i - df_j))
    dPtie_k = 0;
    for i=1:nA
        for j=1:nA
            if i~=j && p.T12(i,j)~=0
                dPtie_k = dPtie_k + p.T12(i,j)*(df(max(k,1),i) - df(max(k,1),j));
            end
        end
    end

    dPtie(k) = dPtie_k;

    ddf = zeros(1,nA);
    dxg = zeros(1,nA);
    dxt = zeros(1,nA);
    dxp = zeros(1,nA);

    for i=1:nA
        % governor
        dxg(i) = (-xg(i) - (1/p.R(i))*df(max(k,1),i)) / p.Tg(i);

        % turbine
        dxt(i) = (-xt(i) + xg(i)) / p.Tt(i);

        % power block
        netInput = xt(i) - p.D(i)*df(max(k,1),i) - dPL(i); % power to plant
        dxp(i)   = (-xp(i) + p.Kp(i)*netInput) / p.Tp(i);

        % swing (freq)
        coupling = 0;
        for j=1:nA
            if i~=j, coupling = coupling + p.T12(i,j)*(df(max(k,1),i) - df(max(k,1),j)); end
        end
        ddf(i) = ( -p.D(i)*df(max(k,1),i) + xp(i) - dPL(i) - coupling ) / (2*H(i));
    end

    % Euler integrate
    xg = xg + dt*dxg(:);
    xt = xt + dt*dxt(:);
    xp = xp + dt*dxp(:);
    df(k,:) = (k>1)*df(k-1,:) + dt*ddf;
end

res.df = df;            % [N x nA]
res.dPtie = dPtie(:);   % [N x 1]
end
