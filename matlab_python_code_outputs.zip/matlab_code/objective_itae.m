% ======================= objective_itae.m =======================
% ITAE = ? t*(|df_all| + |dPtie|) dt
% ---------------------------------------------------------------
function J = objective_itae(p, Hmult, t, dt)
sim = simulate_case(p, Hmult, t, dt);
w_df   = 1.0;
w_ptie = 0.25;

absDf = sum(abs(sim.df),2);      % sum over areas
J = dt * sum( t(:) .* ( w_df*absDf + w_ptie*abs(sim.dPtie) ) );
end



