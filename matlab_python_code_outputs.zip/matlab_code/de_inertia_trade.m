function [bestX, bestJ, histBest] = de_inertia_trade(fitfun, D, lb, ub, opts)
% Differential Evolution baseline (DE/rand/1/bin) (R2016a-safe)
if isscalar(lb), lb = lb*ones(1,D); end
if isscalar(ub), ub = ub*ones(1,D); end
N=opts.pop; MaxIt=opts.iters; F=opts.F; CR=opts.CR;

X = bsxfun(@plus, lb, bsxfun(@times, rand(N,D), (ub - lb)));
J = inf(N,1);
for i=1:N, J(i)=fitfun(X(i,:)); end
histBest = zeros(MaxIt,1);

for it=1:MaxIt
    for i=1:N
        idx = randperm(N,3);
        while any(idx==i), idx = randperm(N,3); end
        x1=X(idx(1),:); x2=X(idx(2),:); x3=X(idx(3),:);

        v = x1 + F*(x2 - x3);
        % binomial crossover
        u = X(i,:);
        jRand = randi(D);
        for j=1:D
            if rand <= CR || j==jRand
                u(j)=v(j);
            end
        end
        % clamp
        u = min(max(u, lb), ub);
        Ju = fitfun(u);
        if Ju < J(i)
            X(i,:) = u; J(i)=Ju;
        end
    end
    histBest(it) = min(J);
end

[bestJ, ii] = min(J);
bestX = X(ii,:);
end
