function K = compute_kpis(t, S)
% KPIs from simulation struct S: df1, df2 (opt), dPtie
band = 0.01;  % settling band (Hz)

df2 = zeros(size(S.df1)); if isfield(S,'df2'), df2 = S.df2; end

K.ITAE   = trapz(t, t(:).*(abs(S.df1(:)) + abs(df2(:)) + abs(S.dPtie(:))));
K.OS_f1  = max(S.df1);  K.US_f1 = min(S.df1);
K.OS_f2  = max(df2);    K.US_f2 = min(df2);
K.ST_f1  = settle_time(t, S.df1, band);
K.ST_f2  = settle_time(t, df2,   band);
K.ST_Ptie= settle_time(t, S.dPtie, band);
end

function st = settle_time(t, y, band)
st = t(end);
ok = abs(y) <= band;
if all(ok), st = t(1); return; end
lastOut = find(~ok,1,'last');
if isempty(lastOut), st = t(1);
else, st = t(min(lastOut+1, numel(t)));
end
end


