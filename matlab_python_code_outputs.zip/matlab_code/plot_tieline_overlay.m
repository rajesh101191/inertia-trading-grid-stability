function plot_tieline_overlay(t, C, R, G, P, D, outDir, cName)
fig = figure('Color','w','Position',[100 100 540 360]);
plot(t,C.dPtie,'k--', t,R.dPtie,'r-', t,G.dPtie,'b', t,P.dPtie,'m', t,D.dPtie,'g','LineWidth',1.2);
grid on; xlabel('Time (s)'); ylabel('\Delta P_{tie} (p.u.)');
legend('Conventional','RES (low H)','GWO','PSO','DE','Location','best');
title('\Delta P_{tie} Overlays');
saveas(fig, fullfile(outDir, [upper(cName) '_tieline_overlays.png']));
close(fig);
end
