function plot_convergence(curves, names, outDir, cName)
fig = figure('Color','w','Position',[100 100 540 360]);
hold on; for k=1:numel(curves), plot(curves{k},'LineWidth',1.2); end
grid on; xlabel('Iteration'); ylabel('Best ITAE'); legend(names,'Location','best');
title('Convergence of Optimizers'); hold off;
saveas(fig, fullfile(outDir, [upper(cName) '_convergence.png']));
close(fig);
end
