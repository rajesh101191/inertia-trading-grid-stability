function p = ensure_fields(p)
% Harmonize fields so simulate_case() never breaks.

% nAreas
if ~isfield(p,'nAreas')
    if isfield(p,'Hbase'), p.nAreas = numel(p.Hbase);
    elseif isfield(p,'D'), p.nAreas = numel(p.D);
    else, p.nAreas = 2; end
end

% Hbase
if ~isfield(p,'Hbase')
    p.Hbase = ones(1,p.nAreas);
end
p.Hbase = reshape(p.Hbase,1,[]);

% D (load damping, p.u.MW/Hz)
if ~isfield(p,'D')
    p.D = 0.015*ones(1,p.nAreas);
end
p.D = reshape(p.D,1,[]);

% Expand scalars to per-area vectors if needed
if isfield(p,'b') && isscalar(p.b), p.b = p.b*ones(1,p.nAreas); end
if isfield(p,'R') && isscalar(p.R), p.R = p.R*ones(1,p.nAreas); end
end

