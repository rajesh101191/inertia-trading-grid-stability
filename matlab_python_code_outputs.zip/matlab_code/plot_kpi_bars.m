function plot_kpi_bars(KPI, outDir, cName)
names = {'RES','GWO','PSO','DE'};
ITAE = [KPI.RES.ITAE, KPI.GWO.ITAE, KPI.PSO.ITAE, KPI.DE.ITAE];
US1  = [KPI.RES.US_f1, KPI.GWO.US_f1, KPI.PSO.US_f1, KPI.DE.US_f1];

fig = figure('Color','w','Position',[100 100 900 360]);
subplot(1,2,1); bar(ITAE); set(gca,'XTickLabel',names); ylabel('ITAE'); title('ITAE vs Method'); grid on;
subplot(1,2,2); bar(US1);  set(gca,'XTickLabel',names); ylabel('Undershoot \Delta f_1 (Hz)'); title('Nadir vs Method'); grid on;
saveas(fig, fullfile(outDir, [upper(cName) '_kpi_bars.png']));
close(fig);
end
