function cases = load_cases_user()
% Build CASE-I..IV from your parameters (R2016a-safe).

% ===== CASE I: Two-area reheat thermal =====
p1.nAreas = 2; p1.F = 50;
p1.TG = 0.07; p1.TT = 0.35; p1.Tr = 9; p1.TP = 18;
p1.Kr = 0.55; p1.KP = 125;
p1.T12 = 0.5501/(2*pi);  % given as 2?T12 = 0.5501
p1.a12 = -1; p1.b = 0.400; p1.R = 2.6;
p1.DPL1 = 0.015;
p1.Hbase = [1 1];               % nominal inertia per area
p1.D     = [0.015 0.015];       % load damping (p.u.MW/Hz)

% ===== CASE II: Two-area multi-source hydro-thermal =====
p2.nAreas = 2; p2.F = 50;
p2.TG = 0.07; p2.TT = 0.35; p2.Tr = 9; p2.TP = 18;
p2.Kr = 0.55; p2.KP = 125;
p2.T12 = 0.075; p2.a12 = -1; p2.b = 0.410; p2.R = 2.5;
p2.Kr_as = 0.25; p2.TA1 = 0.55; p2.TA2 = 0.045; p2.KA_as = 1.3; p2.KC = 1.6;
p2.KB = 0.06; p2.KN = 0.65; p2.KH = 0.22; p2.KW = 0.12;
p2.DPL1 = 0.08;
p2.TD = 27.5; p2.TR = 4.5; p2.TH = 0.25; p2.TW = 0.95;
p2.KA = 1.4; p2.TF = 0.02; p2.AMax = 12; p2.AMin = -12; p2.KE = 1.7; p2.TZ = 0; p2.KR = 1; p2.TC = 0.75;
p2.Hbase = [1 1];
p2.D     = [0.015 0.015];

% ===== CASE III: Three-area unequal non-reheat thermal =====
p3.nAreas = 3; p3.F = 50;
% Area 1
p3.H1x2 = 0.1701; p3.D1 = 0.014; p3.T12 = 0.18; p3.b1 = 0.355; p3.R1 = 2.95; p3.a12 = -1; p3.TG1 = 0.07; p3.TT1 = 0.35;
% Area 2
p3.H2x2 = 0.1983; p3.D2 = 0.017; p3.T23 = 0.13; p3.b2 = 0.375; p3.R2 = 2.65; p3.a23 = -1; p3.TG2 = 0.065; p3.TT2 = 0.42;
% Area 3
p3.H3x2 = 0.1295; p3.D3 = 0.014; p3.T31 = 0.23; p3.b3 = 0.362; p3.R3 = 2.75; p3.a31 = -1; p3.TG3 = 0.07; p3.TT3 = 0.32;
% Derive nominal inertia H from 2H values
p3.Hbase = [0.1701/2, 0.1983/2, 0.1295/2];
p3.D     = [p3.D1, p3.D2, p3.D3];

% ===== CASE IV: Two-area multi-source thermal-hydro-wind =====
p4.nAreas = 2; p4.F = 50;
p4.TG = 0.07; p4.TT = 0.35; p4.Tr = 9; p4.TP = 18;
p4.Kr = 0.55; p4.KP = 125;
p4.T12 = 0.0707; p4.a12 = -1; p4.b = 0.425; p4.R = 2.4;
p4.TD = 27.5; p4.TR = 4.5; p4.TH = 0.2; p4.TW = 1.0;
p4.TA1 = 0.55; p4.TA2 = 0.045; p4.KA_as = 1.3; p4.KC = 1.6;
p4.KB = 0.06; p4.KN = 0.65; p4.KH = 0.22; p4.KW = 0.12;
p4.DPL1 = 0.10;
p4.KA = 1.4; p4.TF = 0.01; p4.AMax = 12; p4.AMin = -12; p4.KE = 1.7; p4.TZ = 0.1; p4.KR = 1; p4.TC = 0.75;
p4.Hbase = [1 1];
p4.D     = [0.015 0.015];

cases.case1 = p1; cases.case2 = p2; cases.case3 = p3; cases.case4 = p4;
end

