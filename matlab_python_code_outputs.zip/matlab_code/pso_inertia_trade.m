function [bestX, bestJ, histBest] = pso_inertia_trade(fitfun, D, lb, ub, opts)
% PSO baseline (R2016a-safe)
if isscalar(lb), lb = lb*ones(1,D); end
if isscalar(ub), ub = ub*ones(1,D); end
N=opts.pop; MaxIt=opts.iters; w=opts.w; c1=opts.c1; c2=opts.c2;

X = bsxfun(@plus, lb, bsxfun(@times, rand(N,D), (ub - lb)));
V = zeros(N,D);
pbestX = X; pbestJ = inf(N,1);
for i=1:N, pbestJ(i)=fitfun(X(i,:)); end
[bestJ, idx] = min(pbestJ); gbestX = pbestX(idx,:);
histBest = zeros(MaxIt,1);

for it=1:MaxIt
    for i=1:N
        r1=rand(1,D); r2=rand(1,D);
        V(i,:) = w*V(i,:) + c1*r1.*(pbestX(i,:)-X(i,:)) + c2*r2.*(gbestX - X(i,:));
        X(i,:) = X(i,:) + V(i,:);
    end
    X = min(max(X, repmat(lb,N,1)), repmat(ub,N,1));
    for i=1:N
        J = fitfun(X(i,:));
        if J < pbestJ(i)
            pbestJ(i)=J; pbestX(i,:)=X(i,:);
        end
    end
    [bestJ, idx] = min(pbestJ); gbestX = pbestX(idx,:);
    histBest(it)=bestJ;
end
bestX = gbestX;
end

